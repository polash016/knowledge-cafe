import React from 'react';

const Answer = () => {
    return (
        <div className='w-[95%] mx-auto mt-8 mb-8 text-xl font-bold'>
            <h1>Difference Between Props And State.</h1>
            <p><span>Props</span> is called immutable data that passes data from parent component to child component. It cannot modify data.It is often used to manage data of child component.</p>
            <p><span>State</span> is called mutable data that manges data within the component. It can modify or change data within the component.</p>
            <h1>How does useState Works.</h1>
            <p>useState hook is a function with two elements. First element is the currents state value & Secons element is a function. The function render data and return and set the current value to first element.</p>
        </div>
    );
};

export default Answer;